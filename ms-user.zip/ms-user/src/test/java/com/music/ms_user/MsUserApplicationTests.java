package com.music.ms_user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
